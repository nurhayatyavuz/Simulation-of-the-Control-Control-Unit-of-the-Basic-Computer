/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module bilgisayarmimarisi {
}