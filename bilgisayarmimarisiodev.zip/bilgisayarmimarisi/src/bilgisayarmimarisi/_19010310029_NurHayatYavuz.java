package bilgisayarmimarisi;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class _19010310029_NurHayatYavuz {

    private int[] memory;

    public _19010310029_NurHayatYavuz(int size) {
        memory = new int[size];
    }

    public void loadProgram(String[] program) {
        if (program.length != memory.length) {
            throw new IllegalArgumentException("Program size does not match RAM size.");
        }

        for (int i = 0; i < program.length; i++) {
            memory[i] = Integer.parseInt(program[i], 2);
        }
    }

    public String readMemory(int address) {
        return String.format("%12s", Integer.toBinaryString(memory[address])).replace(' ', '0');
    }

    public void printMemory() {
        for (int i = 0; i < memory.length; i++) {
            System.out.printf("RAM[%d]: %12s%n", i, Integer.toBinaryString(memory[i]));
        }
    }

    public void executeProgram() {
        String[] instructionSet = {
            "111111111111", "ADD",
            "100000000000", "INP",
            "100000000000", "CLA"
            // Di�er buyruklar� ekleyebilirsiniz
        };

        for (int i = 0; i < 16; i++) {
            String binaryInstruction = Integer.toBinaryString(i);
            int time = i;
            String instruction = readMemory(i);

            System.out.println("T" + time + " zaman�nda I = " + binaryInstruction + " D" + i + " aktif IR(11-0) = " + instruction + " buyruk = " + decodeInstruction(instruction));
            sleep(1000);
        }
    }

    private String decodeInstruction(String instruction) {
        int opcode = Integer.parseInt(instruction.substring(0, 4), 2);

        switch (opcode) {
            case 0b0000:
                return "AND";
            case 0b0001:
                return "ADD";
            case 0b0010:
                return "LDA";
            case 0b0011:
                return "STA";
            case 0b0100:
                return "BUN";
            case 0b0101:
                return "BSA";
            case 0b0110:
                return "ISZ";
            case 0b0111:
                return "CLA";
            case 0b1000:
                return "CLE";
            case 0b1001:
                return "CME";
            case 0b1011:
                return "CIR";
            case 0b1100:
                return "CIL";
            case 0b1101:
                return "INC";
            case 0b1110:
                return "SPA";
            case 0b1111:
                return "SNA";
            default:
                return "Bilinmeyen Buyruk";
        }
    }

    private void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        _19010310029_NurHayatYavuz ram = new _19010310029_NurHayatYavuz(16);

        try (BufferedReader reader = new BufferedReader(new FileReader("RAM.txt"))) {
            String line;
            int lineNumber = 0;
            String[] program = new String[16];

            while ((line = reader.readLine()) != null && lineNumber < 16) {
                program[lineNumber] = line;
                lineNumber++;
            }

            ram.loadProgram(program);
        } catch (IOException e) {
            e.printStackTrace();
        }

        ram.executeProgram();
    }
}
